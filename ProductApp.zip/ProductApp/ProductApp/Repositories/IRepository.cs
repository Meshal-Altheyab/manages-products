﻿using ProductApp.Models;

namespace ProductApp.Repositories
{
    public interface IRepository
    {
        void AddProduct(Product product);
        List<Product> GetAllProducts();
        void UpdateProduct(Product product);
        void DeleteProduct(int id);
    }
}
