﻿using ProductApp.Data;
using ProductApp.Models;

namespace ProductApp.Repositories
{
    public class ProductRepository : IRepository
    {
        private readonly AppDbContext context;

        public ProductRepository()
        {
            context = new AppDbContext();
            context.Database.EnsureCreated(); 
        }

        public void AddProduct(Product product)
        {
            context.Products.Add(product);
            context.SaveChanges();
        }

        public List<Product> GetAllProducts()
        {
            return context.Products.ToList();
        }

        public void UpdateProduct(Product product)
        {
            var existing = context.Products.Find(product.Id);
            if (existing != null)
            {
                existing.Name = product.Name;
                existing.Price = product.Price;
                context.SaveChanges();
            }
        }

        public void DeleteProduct(int id)
        {
            var product = context.Products.Find(id);
            if (product != null)
            {
                context.Products.Remove(product);
                context.SaveChanges();
            }
        }
    }
}
