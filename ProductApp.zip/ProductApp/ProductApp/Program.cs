﻿using ProductApp.Models;
using ProductApp.Repositories;

namespace ProductApp
{
    class Program
    {
        static void Main(string[] args)
        {
            IRepository myRepository = new ProductRepository();

            bool isRunning = true;

            while (isRunning)
            {
                Console.WriteLine("-------- Product Menu --------");
                Console.WriteLine("1. Add a new product");
                Console.WriteLine("2. Show all products");
                Console.WriteLine("3. Update a product");
                Console.WriteLine("4. Delete a product");
                Console.WriteLine("5. Exit");
                Console.Write("Choose a number (1-5): ");

                string userChoice = Console.ReadLine();

                if (userChoice == "1")
                {

                    Console.Write("Enter product name: ");
                    string productName = Console.ReadLine();

                    Console.Write("Enter product price: ");
                    string priceInput = Console.ReadLine();
                    decimal productPrice = Convert.ToDecimal(priceInput);

                    Product newProduct = new Product
                    {
                        Name = productName,
                        Price = productPrice
                    };

                    myRepository.AddProduct(newProduct);
                    Console.WriteLine(" Product added successfully.");
                }



                else if (userChoice == "2")
                {
                    var allProducts = myRepository.GetAllProducts();
                    Console.WriteLine("----- Product List -----");
                    foreach (var item in allProducts)
                    {
                        Console.WriteLine($"ID: {item.Id} | Name: {item.Name} | Price: {item.Price}");
                    }
                }



                else if (userChoice == "3")
                {
                    Console.Write("Enter the ID of the product you want to update: ");
                    int updateId = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Enter new product name: ");
                    string newName = Console.ReadLine();

                    Console.Write("Enter new product price: ");
                    decimal newPrice = Convert.ToDecimal(Console.ReadLine());

                    Product updatedProduct = new Product
                    {
                        Id = updateId,
                        Name = newName,
                        Price = newPrice
                    };

                    myRepository.UpdateProduct(updatedProduct);
                    Console.WriteLine(" Product updated successfully.");
                }



                else if (userChoice == "4")
                {
                    Console.Write("Enter the ID of the product to delete: ");
                    int deleteId = Convert.ToInt32(Console.ReadLine());

                    myRepository.DeleteProduct(deleteId);
                    Console.WriteLine(" Product deleted.");
                }
                else if (userChoice == "5")
                {
                    isRunning = false;
                    Console.WriteLine(" Goodbye!");
                }



                else
                {
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");

                }
            }
        }
    }
}

